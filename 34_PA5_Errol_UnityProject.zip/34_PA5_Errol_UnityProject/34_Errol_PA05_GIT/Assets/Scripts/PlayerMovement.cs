﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;


public class PlayerMovement : MonoBehaviour
{

    float Motion = 40;
    public float ObjectiveNumber;
    private GameObject[] getObj;
    public Text Objectives;
    Rigidbody Player;

    // Start is called before the first frame update
    void Start()
    {
        Scene currentScene = SceneManager.GetActiveScene();
        Player = GetComponent<Rigidbody>();
        getObj = GameObject.FindGameObjectsWithTag("objective");
        ObjectiveNumber = getObj.Length;
    }

    // Update is called once per frame
    void Update()
    {
        Objectives.text = "Coins needed : " + ObjectiveNumber;
        float LR = Input.GetAxis("Horizontal");
        float UD = Input.GetAxis("Vertical");
        Vector3 movement = new Vector3(LR, 0, UD);
        Player.AddForce(movement * Motion * Time.deltaTime);

        if (ObjectiveNumber == 0)
        {
            if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("GamePlay_Level1"))
            {
                SceneManager.LoadScene("GamePlay_Level2");
            }

            else if (SceneManager.GetActiveScene() == SceneManager.GetSceneByName("GamePlay_Level2"))
            {
                SceneManager.LoadScene("Win");
            }
        }
    }

    private void OnTriggerEnter(Collider other)
    {
        if (other.tag == "obstacle")
        {
            SceneManager.LoadScene("Lose");
        }

        if (other.gameObject.tag == "objective")
        {
            ObjectiveNumber -= 1;
            Destroy(other.gameObject);
        }
    }
}
